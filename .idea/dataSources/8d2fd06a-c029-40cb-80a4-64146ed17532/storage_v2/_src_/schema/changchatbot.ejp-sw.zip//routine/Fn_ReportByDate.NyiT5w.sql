create
    definer = chatbotadmin@`%` procedure Fn_ReportByDate(IN p_from varchar(50), IN p_to varchar(50))
BEGIN
    declare v_from varchar(100);
    declare v_to varchar(100);

    set v_from = p_from + interval -7 hour;
    set v_to = p_to + interval -7 hour;

    with training_msg_count as (
        select date(m.date_created) as date,
               count(1) as totalTrainingMsg,
               sum(if(m.content like '%fcare%'
                   or m.content like '%fpt care%'
                   or m.content like '%care%'
                   or m.content like '%bảo hiểm%'
                   , 1, 0)) as totalTrainingMsgHealthcare
        from trainning_messages m
        where m.date_created > v_from and m.date_created < v_to
        group by date
    ),
    msg_count as (
        select date(m.date_created) as date
             , count(distinct id_user) as totalUser
             , sum(if(role = "Human" && content <> "/c", 1, 0)) as humanMsg
             , sum(if(role = "Ai", 1, 0)) as aiMsg
             , sum(if(role = "Human" && content <> "/c" && (m.content like '%fcare%'
            or m.content like '%fpt care%'
            or m.content like '%care%'
            or m.content like '%bảo hiểm%'), 1, 0)) as humanMsgHealthcare
             , sum(if(role = "Ai" && (m.content like '%fcare%'
            or m.content like '%fpt care%'
            or m.content like '%care%'
            or m.content like '%bảo hiểm%'), 1, 0)) as aiMsgHealthcare
        from messages m
        where m.date_created > v_from
          and m.date_created < v_to
        group by date
    )
    select m.*, coalesce(mt.totalTrainingMsg,0) as totalTraining, coalesce(mt.totalTrainingMsgHealthcare, 0) as totalTrainingHealthcare
        from msg_count m
    left join training_msg_count mt on m.date = mt.date;
END;

