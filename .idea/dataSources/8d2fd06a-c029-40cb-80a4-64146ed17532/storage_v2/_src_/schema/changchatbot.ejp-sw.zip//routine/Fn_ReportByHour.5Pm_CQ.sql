create
    definer = chatbotadmin@`%` procedure Fn_ReportByHour(IN p_date varchar(50))
BEGIN
        declare v_from varchar(100);
        declare v_to varchar(100);
        set v_from = p_date + interval -7 hour;
        set v_to = p_date + interval 1 day + interval -7 hour;

        SELECT
            DATE_FORMAT(m.date_created + interval 7 hour, '%Y-%m-%d %H giờ') AS Giờ,
            sum(if(role = "Human", 1, 0)) AS "Số tin nhắn của người"
        FROM messages m
        where m.date_created > v_from
          and m.date_created < v_to
        GROUP BY HOUR(m.date_created)
        ORDER BY m.date_created;
    END;

